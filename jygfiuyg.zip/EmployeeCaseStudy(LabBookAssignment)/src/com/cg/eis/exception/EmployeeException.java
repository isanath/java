package com.cg.eis.exception;

public class EmployeeException extends Exception {
	public EmployeeException() {
		System.out.println("Employee salary should be greater than 3000");
	}
		
}
