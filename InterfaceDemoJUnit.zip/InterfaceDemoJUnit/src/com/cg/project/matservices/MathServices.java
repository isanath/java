package com.cg.project.matservices;

public interface MathServices {
	public abstract int addNumber(int a,int b);
	abstract int subNumbers(int a,int b);
	int multiNumbers(int a,int b);
	
}
