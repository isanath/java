package com.cg.project.matservices;

import java.util.InputMismatchException;

public class MathServicesimpl  implements MathServices{

	@Override
	public int addNumber(int a, int b) throws InputMismatchException{
		if(a<0||b<0) throw new InputMismatchException("Input problem");
		return a+b;
	}

	@Override
	public int subNumbers(int a, int b) throws InputMismatchException{
		if(a<0||b<0) throw new InputMismatchException("Input problem");
		return a-b;
	}

	@Override
	public int multiNumbers(int a, int b) throws InputMismatchException{
		if(a<0||b<0) throw new InputMismatchException("Input problem");
		return a*b;
	}

}
