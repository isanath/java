package com.cg.project.matservices;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exceptions {

	public static void main(String[] args) {
		try{
			Scanner sc= new Scanner(System.in);

			System.out.println("Enter Number");
			int n1=sc.nextInt();
			System.out.println("Enter Number other than 0");
			int n2=sc.nextInt();
			System.out.println(n1/n2);
		}
		catch(InputMismatchException e){
			//e.printStackTrace();
			System.out.println("Enter Numbers only");
		}
		catch(ArithmeticException e){
			e.printStackTrace();
			System.out.println("Enter Second Number other than 0");
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Enter Second Number other than 0");
		}
		System.out.println("Outside try catch block");
		

	}

}
