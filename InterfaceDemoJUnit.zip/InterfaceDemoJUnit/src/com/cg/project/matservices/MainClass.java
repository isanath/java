package com.cg.project.matservices;

public class MainClass {

	public static void main(String[] args) {
		
		MathServicesimpl math=new MathServicesimpl();
		math.addNumber(-1, 0);
		math.subNumbers(-1, -1);

	}

}
